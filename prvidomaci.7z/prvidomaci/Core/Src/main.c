/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"


/* Define LED pin */
#define LED_PIN GPIO_PIN_5
#define LED_PORTA GPIOA
#define LED_PORTB GPIOB

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  HAL_InitTick(TICK_INT_PRIORITY);

  /* Initialize LED GPIO */
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOA_CLK_ENABLE();  // Enable GPIOA clock
  __HAL_RCC_GPIOB_CLK_ENABLE();  // Enable GPIOB clock

  GPIO_InitStruct.Pin = LED_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

  char* ime = "KRISTINA";
  char* prezime = "TRAJKOVIC";
  uint32_t broj_samoglasnika = 0;
  uint32_t broj_suglasnika = 0;

  // Brojanje samoglasnika i suglasnika
  for (int i = 0; ime[i] != '\0'; ++i) {
    if (ime[i] == 'A' || ime[i] == 'E' || ime[i] == 'I' || ime[i] == 'O' || ime[i] == 'U') {
      ++broj_samoglasnika;
    } else {
      ++broj_suglasnika;
    }
  }

  for (int i = 0; prezime[i] != '\0'; ++i) {
    if (prezime[i] == 'A' || prezime[i] == 'E' || prezime[i] == 'I' || prezime[i] == 'O' || prezime[i] == 'U') {
      ++broj_samoglasnika;
    } else {
      ++broj_suglasnika;
    }
  }

  /* Infinite loop */
  while (1)
  {
    // Determine GPIO port based on the number of vowels and consonants
    GPIO_TypeDef *PORT;
    if (broj_samoglasnika > broj_suglasnika) {
      PORT = LED_PORTA;
    } else {
      PORT = LED_PORTB;
    }

    GPIO_InitStruct.Pin = LED_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(PORT, &GPIO_InitStruct);

    // Determine GPIO pin based on the modulo of the sum of lengths
    uint32_t Pin_broj = (strlen(ime) + strlen(prezime)) % 6;

    // Width of pulse and pause
    uint32_t Sirina_Impulsa = strlen(ime);
    uint32_t Sirina_Pauze = strlen(prezime);

    /* Set LED on */
    HAL_GPIO_WritePin(PORT, Pin_broj, GPIO_PIN_SET);
    HAL_Delay(Sirina_Impulsa);

    /* Reset LED off */
    HAL_GPIO_WritePin(PORT, Pin_broj, GPIO_PIN_RESET);
    HAL_Delay(Sirina_Pauze);
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

